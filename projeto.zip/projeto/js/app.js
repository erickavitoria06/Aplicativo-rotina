document.addEventListener('DOMContentLoaded', () => {
  const screens = document.querySelectorAll('.screen');
  const buttons = document.querySelectorAll('[data-screen]');
  if (screens.length) {
    buttons.forEach(button => button.addEventListener('click', () => {
      screens.forEach(s => s.classList.toggle('active', s.id === button.dataset.screen));
      buttons.forEach(b => b.classList.toggle('active', b === button));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }));
    buttons[0]?.classList.add('active');
  }

  document.querySelectorAll('[data-save]').forEach(button => button.addEventListener('click', () => {
    button.textContent = 'Salvo com sucesso ✓';
    setTimeout(() => button.textContent = 'Salvar', 1600);
  }));

  const add = document.querySelector('#addProduct');
  const list = document.querySelector('#listaCompras');
  const total = document.querySelector('#totalCompra');
  let sum = 0;
  add?.addEventListener('click', () => {
    const name = document.querySelector('#produto')?.value.trim();
    const qty = Number(document.querySelector('#quantidade')?.value);
    const price = Number(document.querySelector('#preco')?.value);
    if (!name || qty <= 0 || price < 0) return;
    const item = document.createElement('li');
    item.innerHTML = `<span>${escapeHtml(name)} <small>${qty}</small></span><b>${money(qty * price)}</b>`;
    list.appendChild(item); sum += qty * price; total.textContent = money(sum);
  });

  let water = 0;
  document.querySelectorAll('[data-water]').forEach(button => button.addEventListener('click', () => {
    water = Math.min(2000, water + Number(button.dataset.water));
    document.querySelector('#waterValue').textContent = water.toLocaleString('pt-BR');
    document.querySelector('#waterProgress').style.width = `${water / 20}%`;
  }));
});
function money(value) { return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
function escapeHtml(value) { const div = document.createElement('div'); div.textContent = value; return div.innerHTML; }
