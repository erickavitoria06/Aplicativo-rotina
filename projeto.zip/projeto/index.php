<?php
declare(strict_types=1);
require_once __DIR__ . '/functions.php';
if (!empty($_SESSION['user_id'])) redirect('painel.php');
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NutriWork — Alimentação para quem trabalha</title><link rel="stylesheet" href="css/style.css">
</head>
<body class="landing">
<header class="hero"><div class="hero-inner"><span class="brand">Nutri<span>Work</span> 💚</span><span class="pill">Feito para a rotina real</span>
<h1>Comer bem sem complicar a vida.</h1><p>Organize refeições, compras, gastos, hidratação e metas em um só lugar.</p>
<div class="hero-actions"><a class="btn primary" href="cadastro.php">Criar minha conta</a><a class="btn ghost" href="login.php">Já tenho uma conta</a></div></div></header>
<main class="features"><article><b>🥗 Planejamento</b><span>Monte sua semana de alimentação.</span></article><article><b>🛒 Compras</b><span>Controle produtos e orçamento.</span></article><article><b>💧 Hábitos</b><span>Acompanhe água e metas.</span></article></main>
<footer>NutriWork © 2026 · Tecnologia a favor da alimentação saudável.</footer>
<script src="js/app.js"></script></body></html>
