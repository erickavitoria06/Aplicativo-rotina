# NutriWork — Projeto

## Estrutura
- `index.php` — apresentação
- `cadastro.php` — cadastro seguro
- `login.php` — autenticação
- `painel.php` — área autenticada e módulos do app
- `logout.php` — encerramento de sessão
- `config.php` / `functions.php` — sessão, CSRF, validação e armazenamento
- `css/style.css` — estilos
- `js/app.js` — interações do app
- `data/users.json` — armazenamento provisório, **não é banco de dados**

## Segurança implementada
- `password_hash()` / `password_verify()` para senhas
- token CSRF nos formulários de cadastro e login
- regeneração do ID da sessão após autenticação
- cookie de sessão com `HttpOnly` e `SameSite=Lax`
- escape de saída com `htmlspecialchars`
- validação de e-mail, nome e requisitos de senha
- armazenamento com `LOCK_EX`
- arquivo de usuários protegido por `.htaccess` em servidores Apache

## Como executar
Com PHP instalado, dentro desta pasta:

```bash
php -S localhost:8000
```

Depois abra `http://localhost:8000`.

> Esta versão deliberadamente não usa MySQL, SQLite ou outro banco. O JSON é apenas uma solução temporária para demonstrar cadastro/autenticação funcionando. Em produção, substitua-o por um banco e mantenha credenciais fora do código.
