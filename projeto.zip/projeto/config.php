<?php
declare(strict_types=1);

session_name('nutriwork_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

const USERS_FILE = __DIR__ . '/data/users.json';
const MIN_PASSWORD_LENGTH = 8;

if (!is_file(USERS_FILE)) {
    file_put_contents(USERS_FILE, "[]", LOCK_EX);
}
