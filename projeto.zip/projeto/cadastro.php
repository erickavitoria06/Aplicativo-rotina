<?php
declare(strict_types=1);
require_once __DIR__ . '/functions.php';
if (!empty($_SESSION['user_id'])) redirect('painel.php');
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim((string)($_POST['name'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');
    if (!valid_name($name)) $errors[] = 'Informe seu nome completo.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) $errors[] = 'Informe um e-mail válido.';
    if (!valid_password($password)) $errors[] = 'A senha deve ter pelo menos 8 caracteres, incluindo maiúscula, minúscula e número.';
    if ($password !== $confirm) $errors[] = 'As senhas não coincidem.';
    if (find_user_by_email($email)) $errors[] = 'Já existe uma conta com este e-mail.';
    if (!$errors) {
        $users = load_users();
        $users[] = ['id'=>bin2hex(random_bytes(16)), 'name'=>$name, 'email'=>$email,
            'password'=>password_hash($password, PASSWORD_DEFAULT), 'created_at'=>date('c')];
        if (!save_users($users)) $errors[] = 'Não foi possível salvar o cadastro. Verifique as permissões da pasta data.';
        else { session_regenerate_id(true); $_SESSION['user_id'] = $users[array_key_last($users)]['id']; $_SESSION['csrf'] = bin2hex(random_bytes(32)); redirect('painel.php'); }
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Criar conta — NutriWork</title><link rel="stylesheet" href="css/style.css"></head>
<body class="auth-page"><main class="auth-card"><a class="brand dark" href="index.php">Nutri<span>Work</span> 💚</a><div class="auth-heading"><h1>Crie sua conta</h1><p>Comece organizando sua alimentação de acordo com sua rotina.</p></div>
<?php if ($errors): ?><div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?=e($error)?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" novalidate><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>Nome completo<input name="name" type="text" autocomplete="name" maxlength="100" required value="<?=e((string)($_POST['name'] ?? ''))?>"></label><label>E-mail<input name="email" type="email" autocomplete="email" maxlength="190" required value="<?=e((string)($_POST['email'] ?? ''))?>"></label><label>Senha<input id="password" name="password" type="password" autocomplete="new-password" required minlength="8"><small>Use 8+ caracteres, com maiúscula, minúscula e número.</small></label><label>Confirmar senha<input name="confirm_password" type="password" autocomplete="new-password" required minlength="8"></label><button class="btn primary full" type="submit">Criar conta</button></form><p class="auth-foot">Já possui uma conta? <a href="login.php">Entrar</a></p></main><script src="js/app.js"></script></body></html>
