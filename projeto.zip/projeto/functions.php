<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never {
    header('Location: ' . $path);
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function verify_csrf(): void {
    $token = $_POST['csrf'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf'] ?? '', $token)) {
        http_response_code(403);
        exit('Solicitação inválida. Atualize a página e tente novamente.');
    }
}

function load_users(): array {
    $json = @file_get_contents(USERS_FILE);
    if ($json === false) return [];
    $users = json_decode($json, true);
    return is_array($users) ? $users : [];
}

function save_users(array $users): bool {
    return file_put_contents(
        USERS_FILE,
        json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    ) !== false;
}

function find_user_by_email(string $email): ?array {
    foreach (load_users() as $user) {
        if (hash_equals($user['email'], $email)) return $user;
    }
    return null;
}

function require_auth(): void {
    if (empty($_SESSION['user_id'])) redirect('login.php');
}

function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    foreach (load_users() as $user) {
        if (hash_equals((string)$user['id'], (string)$_SESSION['user_id'])) return $user;
    }
    return null;
}

function valid_name(string $name): bool {
    return strlen(trim($name)) >= 2 && strlen(trim($name)) <= 100;
}

function valid_password(string $password): bool {
    return strlen($password) >= MIN_PASSWORD_LENGTH
        && preg_match('/[A-Z]/', $password)
        && preg_match('/[a-z]/', $password)
        && preg_match('/\d/', $password);
}
