<?php
declare(strict_types=1);
require_once __DIR__ . '/functions.php';
if (!empty($_SESSION['user_id'])) redirect('painel.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $user = find_user_by_email($email);
    if (!$user || !password_verify($password, $user['password'])) {
        $error = 'E-mail ou senha incorretos.';
    } else {
        session_regenerate_id(true); $_SESSION['user_id'] = $user['id']; $_SESSION['csrf'] = bin2hex(random_bytes(32)); redirect('painel.php');
    }
}
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Entrar — NutriWork</title><link rel="stylesheet" href="css/style.css"></head>
<body class="auth-page"><main class="auth-card compact"><a class="brand dark" href="index.php">Nutri<span>Work</span> 💚</a><div class="auth-heading"><h1>Bem-vindo de volta</h1><p>Entre para continuar sua organização.</p></div><?php if ($error): ?><div class="alert error" role="alert"><?=e($error)?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><label>E-mail<input name="email" type="email" autocomplete="email" required value="<?=e((string)($_POST['email'] ?? ''))?>"></label><label>Senha<input name="password" type="password" autocomplete="current-password" required></label><button class="btn primary full" type="submit">Entrar</button></form><p class="auth-foot">Ainda não tem conta? <a href="cadastro.php">Criar cadastro</a></p></main></body></html>
